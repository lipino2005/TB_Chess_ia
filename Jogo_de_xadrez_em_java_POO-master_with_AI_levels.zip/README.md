Jogo de xadrez em java, trabalho Programação Orientada a Objetos
